﻿public class ValidationException : Exception
{
    public ValidationException(string message)
        : base(message)
    {
    }

    public Dictionary<string, string[]> Errors { get; set; } = [];
}
