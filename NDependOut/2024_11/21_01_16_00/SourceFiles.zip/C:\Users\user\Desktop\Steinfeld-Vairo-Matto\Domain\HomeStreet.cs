﻿namespace SmartHub.Domain;
public readonly struct HomeStreet
{
    public string Street { get; }
    public int Number { get; }

    public HomeStreet(string street, int number)
    {
        Street = street;
        Number = number;
    }
}
