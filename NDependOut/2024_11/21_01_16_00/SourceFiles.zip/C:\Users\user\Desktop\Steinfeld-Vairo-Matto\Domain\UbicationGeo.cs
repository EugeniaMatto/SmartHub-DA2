﻿namespace SmartHub.Domain;
public readonly struct UbicationGeo
{
    public int Lat { get; }
    public int Lon { get; }

    public UbicationGeo(int lat, int lon)
    {
        Lat = lat;
        Lon = lon;
    }
}
