﻿namespace SmartHub.Model.Request;
public class ImportDevicesRequest
{
    public required string Source { get; set; }
    public required string Type { get; set; }
}
