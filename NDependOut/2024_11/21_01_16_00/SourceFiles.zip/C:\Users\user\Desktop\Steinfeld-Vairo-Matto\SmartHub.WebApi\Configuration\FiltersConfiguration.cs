﻿using SmartHub.WebApi.Filters;

namespace SmartHub.WebApi.Configuration;

public static class FiltersConfiguration
{
    public static void Configure(WebApplicationBuilder builder)
    {
        builder.Services.AddScoped<AuthenticationFilterAttribute>();
        builder.Services.AddScoped<AuthorizationFilterAttribute>();
        builder.Services.AddScoped<ExceptionFilter>();
    }
}
