using Microsoft.EntityFrameworkCore;
using SmartHub.DB;

public static class AppConfiguration
{
    public static void ConfigureApp(WebApplication app)
    {
        if (app.Environment.IsDevelopment())
        {
            using var scope = app.Services.CreateScope();
            var context = scope.ServiceProvider.GetRequiredService<SmartHubAPIContext>();
            var pendingMigrations = context.Database.GetPendingMigrations();

            if (pendingMigrations.Any())
            {
                context.Database.Migrate();
            }
        }

        app.UseCors("AllowFrontendApp");
        app.UseHttpsRedirection();
        app.UseAuthorization();
        app.MapControllers();
    }
}
