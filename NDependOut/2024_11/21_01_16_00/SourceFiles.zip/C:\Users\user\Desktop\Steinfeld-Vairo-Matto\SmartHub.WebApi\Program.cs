var builder = WebApplication.CreateBuilder(args);

ServiceConfiguration.ConfigureServices(builder);

var app = builder.Build();

AppConfiguration.ConfigureApp(app);

app.Run();
