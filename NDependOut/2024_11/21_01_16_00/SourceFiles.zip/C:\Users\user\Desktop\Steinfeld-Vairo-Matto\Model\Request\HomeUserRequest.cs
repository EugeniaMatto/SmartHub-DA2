﻿namespace SmartHub.Model.Request;

public class HomeUserRequest
{
    public string? Email { get; set; }
}
