﻿namespace SmartHub.Domain;
public class SecurityCam : Device
{
    public HashSet<UseType> UseTypes { get; set; } = [];
    public HashSet<CamSupportedActions> CamSupportedActions { get; set; } = [];
}
