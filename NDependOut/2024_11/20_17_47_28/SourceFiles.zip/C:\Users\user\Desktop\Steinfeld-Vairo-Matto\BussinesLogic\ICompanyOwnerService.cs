﻿using Domain;
using Model.Request;

namespace BussinesLogic;
public interface ICompanyOwnerService
{
    User CreateCompanyOwnerAccount(CompanyOwnerRequest newAccount);
}
