using Domain;
using Model.Response;

namespace BussinesLogic;
public interface IUserService
{
    User Login(string username, string password);
    Guid AddAccount(User newUser);
    bool DeleteAccount(User user, Role role);
    void UpdateAccount(User user);
    IEnumerable<User> GetAccounts();
    User GetById(string userId);
    List<UserHomeResponse> GetHomes(User user);
    UserResponse ChangeProfilePhoto(User user, string photo);
    List<string> GetEmails(Role role);
}
