﻿using Domain;
using Model.Request;
using Model.Response;

namespace BussinesLogic;
public interface IWindowSensorService
{
    Guid AddSensor(DeviceRequest device, User user);
    List<NotificationResponse> Open(Guid hardwareId);
    List<NotificationResponse> Close(Guid hardwareId);
}
