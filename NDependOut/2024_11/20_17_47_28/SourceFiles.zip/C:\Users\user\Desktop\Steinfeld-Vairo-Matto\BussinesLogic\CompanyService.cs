﻿using System.Data;
using DataAccess;
using Domain;
using Model.Request;
using Model.Response;
namespace BussinesLogic;
public class CompanyService : ICompanyService
{
    private readonly IRepository<Company> _companyRepository;

    public CompanyService(IRepository<Company> companyRepository)
    {
        _companyRepository = companyRepository;
    }

    public Guid CreateCompany(CompanyRequest request, User user)
    {
        var company = new Company(request.Name, request.LogoUrl, user, request.Rut);
        try
        {
            _companyRepository.Add(company);
        }
        catch
        {
            throw new Exception("Already the owner of a company");
        }

        return company.Id;
    }

    public PaginatedResult<CompanyModel> GetAllCompanies(string? companyName, string? fullName, int pageNumber, int pageSize)
    {
        var query = _companyRepository.GetAll(null, c => c.Owner);

        if (!string.IsNullOrEmpty(companyName))
        {
            query = query.Where(c => c.Name.ToLower().Contains(companyName.ToLower()));
        }

        if (!string.IsNullOrEmpty(fullName))
        {
            query = query.Where(u => (u.Owner.Name + " " + u.Owner.Surname).ToLower().Contains(fullName.ToLower()));
        }

        var total = query.Count();

        var items = query.Skip((pageNumber - 1) * pageSize).Take(pageSize)
            .Select(c => new CompanyModel
            {
                Name = c.Name,
                Logo = c.LogoURL,
                Rut = c.Rut,
                Owner = c.Owner.Name + " " + c.Owner.Surname,
                OwnerEmail = c.Owner.Email,
                DeviceModelValidator = c.Validator
            }).ToList();

        return new PaginatedResult<CompanyModel>(
            items,
            total,
            pageNumber,
            pageSize);
    }

    public CompanyResponse GetCompany(User user)
    {
        var company = _companyRepository.Get(
            c => c.OwnerId == user.Id,
            c => c.Devices);

        return new CompanyResponse(
            company.Name,
            company.LogoURL,
            company.Rut,
            company.Devices.Select(device => new DeviceResponse(device, company)).ToList(),
            company.Validator);
    }
}
