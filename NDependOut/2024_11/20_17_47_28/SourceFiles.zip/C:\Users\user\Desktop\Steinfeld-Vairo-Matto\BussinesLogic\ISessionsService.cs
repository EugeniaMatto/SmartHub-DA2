﻿using Domain;
using Model.Response;

namespace BussinesLogic;
public interface ISessionsService
{
    User GetUserByToken(string token);
    SessionResponse AddSession(User user);
    bool ExpiredSession(string token);
}
