﻿using Domain;
using Model.Request;

namespace BussinesLogic;

public interface IAdministratorService
{
    User CreateAdminAccount(AdministratorRequest newAdmin);
    void DeleteAdminAccount(Guid accountId);
}
