﻿namespace BussinesLogic.deviceImporter;
public interface IDeviceImporterFactory
{
    IDeviceImporter GetImporter(string importerType);
    List<string> GetRegisteredImporters();
}
