﻿namespace Domain;
public class SmartLampHardware : Hardware
{
    public bool IsOn { get; set; } = false;
}
