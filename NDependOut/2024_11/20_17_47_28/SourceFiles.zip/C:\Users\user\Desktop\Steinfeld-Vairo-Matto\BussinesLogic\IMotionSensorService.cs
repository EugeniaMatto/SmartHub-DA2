﻿using Domain;
using Model.Request;
using Model.Response;

namespace BussinesLogic;
public interface IMotionSensorService
{
    Guid AddMotionSensor(DeviceRequest device, User user);
    List<NotificationResponse> MotionDetection(Guid hardwareId);
}
