﻿using Domain;
using Model.Request;
using Model.Response;

namespace BussinesLogic;
public class SmartLampService : ISmartLampService
{
    private readonly IDeviceService _deviceService;
    private readonly INotificationService _notificationService;

    public SmartLampService(IDeviceService deviceService, INotificationService notificationService)
    {
        _deviceService = deviceService;
        _notificationService = notificationService;
    }

    public Guid AddSmartLamp(DeviceRequest device, User user)
    {
        var newDevice = new Device
        {
            Name = device.Name,
            Model = device.ModelNumber,
            Type = DeviceType.SmartLamp,
            Description = device.Description,
            Photos = device.Photos
        };

        _deviceService.AddDevice(newDevice, user);
        return newDevice.Id;
    }

    public List<NotificationResponse> On(Guid hardwareId)
    {
        var hardware = _deviceService.GetHardwareById(hardwareId);

        if (!hardware.Device.Type.Equals(DeviceType.SmartLamp))
        {
            throw new Exception($"Hardware {hardwareId} does not have a SmartLamp device.");
        }

        var smartLamp = hardware as SmartLampHardware;

        if (smartLamp!.IsOn)
        {
            throw new Exception("Smart Lamp already ON.");
        }

        smartLamp.IsOn = true;
        _deviceService.UpdateHardware(smartLamp);
        return _notificationService.AddNotification(hardwareId, "Smart Lamp Alert: ON");
    }

    public List<NotificationResponse> Off(Guid hardwareId)
    {
        var hardware = _deviceService.GetHardwareById(hardwareId);

        if (!hardware.Device.Type.Equals(DeviceType.SmartLamp))
        {
            throw new Exception($"Hardware {hardwareId} does not have a SmartLamp device.");
        }

        var smartLamp = hardware as SmartLampHardware;

        if (!smartLamp!.IsOn)
        {
            throw new Exception("Smart Lamp already OFF.");
        }

        smartLamp.IsOn = false;
        _deviceService.UpdateHardware(smartLamp);
        return _notificationService.AddNotification(hardwareId, "Smart Lamp Alert: OFF");
    }
}
