﻿using Domain;
using Model.Request;
using Model.Response;

namespace BussinesLogic;
public class CameraService : ICameraService
{
    private readonly IDeviceService _deviceService;
    private readonly INotificationService _notificationService;

    public CameraService(IDeviceService deviceService, INotificationService notificationService)
    {
        _deviceService = deviceService;
        _notificationService = notificationService;
    }

    public Guid AddCamera(DeviceCamRequest device, User user)
    {
        var newDevice = new SecurityCam
        {
            Name = device.Name,
            Model = device.ModelNumber,
            Type = DeviceType.SecurityCam,
            Description = device.Description,
            Photos = device.Photos,
            UseTypes = MapUseTypes(device.UseTypes),
            CamSupportedActions = MapSupportedActions(device.SupportedActions)
        };

        _deviceService.AddDevice(newDevice, user);

        return newDevice.Id;
    }

    public List<NotificationResponse> PersonDetection(Guid hardwareId, string? userDetected)
    {
        var hardware = _deviceService.GetHardwareById(hardwareId);

        if (hardware.Device is not SecurityCam securityCam)
        {
            throw new Exception($"Hardware {hardwareId} does not have a SecurityCam device.");
        }

        if (!securityCam.CamSupportedActions.Contains(CamSupportedActions.PersonDetection))
        {
            throw new Exception($"SecurityCam {hardwareId} does not support Person Detection.");
        }

        var description = "Camera Alert: Person detected";
        if (!string.IsNullOrEmpty(userDetected))
        {
            description += $": {userDetected}";
        }

        return _notificationService.AddNotification(hardwareId, description);
    }

    public List<NotificationResponse> MotionDetection(Guid hardwareId)
    {
        var hardware = _deviceService.GetHardwareById(hardwareId);

        if (hardware.Device is not SecurityCam securityCam)
        {
            throw new Exception($"Hardware {hardwareId} does not have a SecurityCam device.");
        }

        if (!securityCam.CamSupportedActions.Contains(CamSupportedActions.MotionDetection))
        {
            throw new Exception($"SecurityCam {hardwareId} does not support Motion Detection.");
        }

        return _notificationService.AddNotification(hardwareId, "Camera Alert: Motion detected");
    }

    private HashSet<UseType> MapUseTypes(List<string> useTypes)
    {
        var mappedUseTypes = new HashSet<UseType>();
        foreach (var useType in useTypes)
        {
            if (Enum.TryParse(useType, true, out UseType parsedUseType))
            {
                mappedUseTypes.Add(parsedUseType);
            }
            else
            {
                throw new ArgumentException($"Invalid UseType: {useType}");
            }
        }

        return mappedUseTypes;
    }

    private HashSet<CamSupportedActions> MapSupportedActions(List<string> supportedActions)
    {
        var mappedSupportedActions = new HashSet<CamSupportedActions>();
        foreach (var action in supportedActions)
        {
            if (Enum.TryParse(action, true, out CamSupportedActions parsedAction))
            {
                mappedSupportedActions.Add(parsedAction);
            }
            else
            {
                throw new ArgumentException($"Invalid SupportedAction: {action}");
            }
        }

        return mappedSupportedActions;
    }
}
