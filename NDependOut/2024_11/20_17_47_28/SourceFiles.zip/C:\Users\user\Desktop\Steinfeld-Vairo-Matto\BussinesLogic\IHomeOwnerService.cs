﻿using Domain;
using Model.Request;

namespace BussinesLogic;
public interface IHomeOwnerService
{
    User CreateHomeOwnerAccount(HomeOwnerRequest newHomeOwner);
    void AddPermissionToUser(User user);
    List<string> GetUserEmails();
}
