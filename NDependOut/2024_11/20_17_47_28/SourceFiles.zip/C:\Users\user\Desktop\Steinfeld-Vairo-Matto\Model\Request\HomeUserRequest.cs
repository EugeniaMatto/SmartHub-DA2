﻿namespace Model;

public class HomeUserRequest
{
    public string? Email { get; set; }
}
