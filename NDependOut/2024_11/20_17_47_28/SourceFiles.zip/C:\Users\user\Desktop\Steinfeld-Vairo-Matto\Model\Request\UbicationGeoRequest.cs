﻿namespace Model.Request;

public class UbicationGeoRequest
{
    public int? Lat { get; set; }
    public int? Lon { get; set; }
}
