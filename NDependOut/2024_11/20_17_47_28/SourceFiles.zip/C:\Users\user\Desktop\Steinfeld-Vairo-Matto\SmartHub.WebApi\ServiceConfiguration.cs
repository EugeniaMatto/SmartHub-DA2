using BussinesLogic;
using BussinesLogic.deviceImporter;
using BussinesLogic.ModelValidator;
using DataAccess;
using DB;
using Domain;
using Microsoft.EntityFrameworkCore;
using WebApi.Filters;
public static class ServiceConfiguration
{
    public static void ConfigureServices(WebApplicationBuilder builder)
    {
        builder.Services.AddCors(options =>
        {
            options.AddPolicy("AllowFrontendApp", builder =>
            {
                builder.WithOrigins("http://localhost:4200")
                       .AllowAnyHeader()
                       .AllowAnyMethod()
                       .AllowCredentials();
            });
        });

        builder.Services.AddDbContext<SmartHubAPIContext>(options =>
            options.UseSqlServer(builder.Configuration.GetConnectionString("SmartHub")));

        builder.Services.AddControllers(options =>
        {
            options.Filters.Add<ExceptionFilter>();
        })
        .ConfigureApiBehaviorOptions(options =>
        {
            options.SuppressModelStateInvalidFilter = true;
        });

        var services = builder.Services;
        services.AddScoped<ISessionsService, SessionsService>();
        services.AddScoped<IPermissionService, PermissionService>();
        services.AddScoped<IHomeService, HomeService>();
        services.AddScoped<IMemberService, MemberService>();
        services.AddScoped<ICompanyService, CompanyService>();
        services.AddScoped<IDeviceService, DeviceService>();
        services.AddScoped<INotificationService, NotificationService>();
        services.AddScoped<IAdministratorService, AdministratorService>();
        services.AddScoped<IHomeOwnerService, HomeOwnerService>();
        services.AddScoped<IUserService, UserService>();
        services.AddScoped<ICompanyOwnerService, CompanyOwnerService>();
        services.AddScoped<IAccountService, AccountService>();
        services.AddScoped<IWindowSensorService, WindowSensorService>();
        services.AddScoped<IMotionSensorService, MotionSensorService>();
        services.AddScoped<ICameraService, CameraService>();
        services.AddScoped<ISmartLampService, SmartLampService>();
        services.AddScoped<IDeviceImporterFactory, DeviceImporterFactory>();
        services.AddScoped<IDeviceModelValidator, DeviceModelValidator>();

        services.AddScoped<AuthenticationFilterAttribute>();
        services.AddScoped<AuthorizationFilterAttribute>();
        services.AddScoped<ExceptionFilter>();

        services.AddScoped<IRepository<Company>, Repository<Company>>();
        services.AddScoped<IRepository<User>, Repository<User>>();
        services.AddScoped<IRepository<Hardware>, Repository<Hardware>>();
        services.AddScoped<IRepository<Device>, Repository<Device>>();
        services.AddScoped<IRepository<Notification>, Repository<Notification>>();
        services.AddScoped<IRepository<Home>, Repository<Home>>();
        services.AddScoped<IRepository<Permission>, Repository<Permission>>();
        services.AddScoped<IRepository<UserHomePermission>, Repository<UserHomePermission>>();
        services.AddScoped<IRepository<NotificationMember>, Repository<NotificationMember>>();
        services.AddScoped<IRepository<SessionUser>, Repository<SessionUser>>();
    }
}
