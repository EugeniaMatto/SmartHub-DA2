﻿using Domain;
using Model.Response;

namespace BussinesLogic;
public class AccountService : IAccountService
{
    private readonly IUserService _userService;

    public AccountService(IUserService userService)
    {
        _userService = userService;
    }

    public PaginatedResult<AccountResponse> GetAll(string? role, string? fullName, int pageNumber, int pageSize)
    {
        var query = _userService.GetAccounts();

        if (!string.IsNullOrEmpty(role))
        {
            if (Enum.TryParse(role, true, out Role roleEnum))
            {
                query = query.Where(u => u.Roles.Any(r => r.ToString() == role));
            }
            else
            {
                throw new ArgumentException("Not valid Role.");
            }
        }

        if (!string.IsNullOrEmpty(fullName))
        {
            query = query.Where(u => (u.Name + " " + u.Surname).Contains(fullName, StringComparison.OrdinalIgnoreCase));
        }

        var totalAccounts = query.Count();

        var accounts = query.Skip((pageNumber - 1) * pageSize).Take(pageSize)
            .Select(u => new AccountResponse(u.Id, u.Name, u.Surname, u.Name + " " + u.Surname, u.Roles.ConvertAll(r => r.ToString()), u.CreatedAt, u.Email))
            .ToList();
        return new PaginatedResult<AccountResponse>(
            accounts,
            totalAccounts,
            pageNumber,
            pageSize);
    }
}
