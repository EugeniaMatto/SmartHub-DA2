﻿namespace Model;
public class PatchRoomRequest
{
    public List<string> Rooms { get; set; } = null!;
}
