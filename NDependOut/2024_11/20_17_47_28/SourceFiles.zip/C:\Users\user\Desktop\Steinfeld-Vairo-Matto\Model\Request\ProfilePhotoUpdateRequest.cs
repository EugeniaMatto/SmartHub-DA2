﻿namespace Model.Request;
public class ProfilePhotoUpdateRequest
{
    public required string Photo { get; set; }
}
