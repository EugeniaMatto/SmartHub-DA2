﻿using BussinesLogic.deviceImporter;
using BussinesLogic.ModelValidator;
using DataAccess;
using Domain;
using Model.Request;
using Model.Response;
using ModeloValidador.Abstracciones;

namespace BussinesLogic;

public class DeviceService : IDeviceService
{
    private readonly IRepository<Device> _deviceRepository;
    private readonly IRepository<Company> _companyRepository;
    private readonly IRepository<Hardware> _hardwareRepository;
    private readonly IDeviceImporterFactory _importerFactory;
    private readonly IDeviceModelValidator _modelValidator;

    public DeviceService(
        IRepository<Device> deviceRepository,
        IRepository<Company> companyRepository,
        IRepository<Hardware> hardwareRepository,
        IDeviceImporterFactory importerFactory,
        IDeviceModelValidator modelValidator)
    {
        _deviceRepository = deviceRepository;
        _companyRepository = companyRepository;
        _hardwareRepository = hardwareRepository;
        _importerFactory = importerFactory;
        _modelValidator = modelValidator;
    }

    public PaginatedResult<DeviceResponse> GetDevices(string? name, string? model, string? companyName, DeviceType? deviceType, int pageNumber, int pageSize)
    {
        var query = _deviceRepository.GetAll(null, d => d.Company);

        if (!string.IsNullOrEmpty(name))
        {
            query = query.Where(d => d.Name.ToLower().Contains(name.ToLower()));
        }

        if (!string.IsNullOrEmpty(model))
        {
            query = query.Where(d => d.Model.ToLower().Contains(model.ToLower()));
        }

        if (!string.IsNullOrEmpty(companyName))
        {
            query = query.Where(d => d.Company.Name.ToLower().Contains(companyName.ToLower()));
        }

        if (deviceType.HasValue)
        {
            query = query.Where(d => d.Type == deviceType.Value);
        }

        var totalItems = query.Count();
        var items = query.Skip((pageNumber - 1) * pageSize).Take(pageSize).ToList();

        var deviceInfos = items.Select(device => new DeviceResponse(device, device.Company)).ToList();

        return new PaginatedResult<DeviceResponse>(
            deviceInfos,
            totalItems,
            pageNumber,
            pageSize);
    }

    public List<string> GetDeviceTypes()
    {
        return Enum.GetNames(typeof(DeviceType)).ToList();
    }

    public void AddDevice(Device device, User user)
    {
        if (!user.Roles.Contains(Role.CompanyOwner))
        {
            throw new Exception("User is not Company Owner.");
        }

        var company = _companyRepository.Get(c => c.OwnerId == user.Id, null);
        device.Company = company;
        device.CompanyId = company.Id;

        if (company.Validator != string.Empty)
        {
            IModeloValidador validator = _modelValidator.GetValidator(device.Company.Validator);
            var esValido = validator.EsValido(new Modelo(device.Model));
            if (!esValido)
            {
                throw new Exception($"The model provided is invalid according to the specified validator {company.Validator}.");
            }
        }

        _deviceRepository.Add(device);
    }

    public Hardware GetHardwareById(Guid hardwareId)
    {
        if (hardwareId == Guid.Empty)
        {
            throw new ArgumentException("The provided hardwareId is not a valid GUID.");
        }

        var hardware = _hardwareRepository.Get(
            h => h.Id == hardwareId,
            h => h.Device, h => h.Device.Company);

        return hardware;
    }

    public Guid UpdateHardware(Hardware hardware)
    {
        _hardwareRepository.Update(hardware);
        return hardware.Id;
    }

    public ImportDevicesResponse ImportDevices(ImportDevicesRequest request, User user)
    {
        IDeviceImporter importer = _importerFactory.GetImporter(request.Type);

        var devices = importer.ImportDevices(request.Source);

        var deviceInfos = devices.Select(device =>
        {
            var company = _companyRepository.Get(c => c.OwnerId == user.Id, null);
            device.Company = company;
            device.CompanyId = company.Id;
            _deviceRepository.Add(device);
            return new DeviceResponse(device, device.Company);
        }).ToList();

        var result = new ImportDevicesResponse(devices.Count, deviceInfos);

        return result;
    }

    public List<string> GetRegisteredImporters()
    {
        return _importerFactory.GetRegisteredImporters();
    }

    public string SelectDeviceValidator(string validator, User user)
    {
        IModeloValidador importer = _modelValidator.GetValidator(validator);
        var company = _companyRepository.Get(c => c.OwnerId == user.Id, null);
        company.Validator = validator;
        _companyRepository.Update(company);
        return $"Validator {validator} selected successfully";
    }

    public List<string> GetRegisteredValidators()
    {
        return _modelValidator.GetRegisteredValidators();
    }

    public void HardwareTurnOff(string hardwareId, User user)
    {
        var hardware = GetHardwareById(Guid.Parse(hardwareId));
        if (hardware.Online == false)
        {
            throw new InvalidOperationException("The hardware is already turned off.");
        }

        hardware.Online = false;
        _hardwareRepository.Update(hardware);
    }

    public void HardwareTurnOn(string hardwareId, User user)
    {
        var hardware = GetHardwareById(Guid.Parse(hardwareId));
        if (hardware.Online == true)
        {
            throw new InvalidOperationException("The hardware is already turned on.");
        }

        hardware.Online = true;
        _hardwareRepository.Update(hardware);
    }
}
