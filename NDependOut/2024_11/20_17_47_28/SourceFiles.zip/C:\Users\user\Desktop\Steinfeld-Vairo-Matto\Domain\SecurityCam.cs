﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json;

namespace Domain;
public class SecurityCam : Device
{
    public string UseTypeJson { get; set; } = string.Empty;
    public string CamSupportedActionsJson { get; set; } = string.Empty;

    [NotMapped]
    public HashSet<UseType> UseTypes
    {
        get => string.IsNullOrEmpty(UseTypeJson) ? [] : JsonSerializer.Deserialize<HashSet<UseType>>(UseTypeJson);
        set => UseTypeJson = JsonSerializer.Serialize(value);
    }

    [NotMapped]
    public HashSet<CamSupportedActions> CamSupportedActions
    {
        get => string.IsNullOrEmpty(CamSupportedActionsJson) ? [] : JsonSerializer.Deserialize<HashSet<CamSupportedActions>>(CamSupportedActionsJson);
        set => CamSupportedActionsJson = JsonSerializer.Serialize(value);
    }
}
