﻿using ModeloValidador.Abstracciones;

namespace BussinesLogic.ModelValidator;
public interface IDeviceModelValidator
{
    IModeloValidador GetValidator(string validatorType);
    List<string> GetRegisteredValidators();
}
