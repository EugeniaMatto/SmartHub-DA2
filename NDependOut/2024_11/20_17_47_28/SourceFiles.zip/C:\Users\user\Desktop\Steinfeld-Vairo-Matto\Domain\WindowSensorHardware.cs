﻿namespace Domain;
public class WindowSensorHardware : Hardware
{
    public bool IsOpen { get; set; } = false;
}
