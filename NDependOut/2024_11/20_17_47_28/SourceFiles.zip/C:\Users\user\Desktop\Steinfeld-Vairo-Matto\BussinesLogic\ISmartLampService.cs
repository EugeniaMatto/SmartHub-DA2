﻿using Domain;
using Model.Request;
using Model.Response;

namespace BussinesLogic;
public interface ISmartLampService
{
    Guid AddSmartLamp(DeviceRequest device, User user);
    List<NotificationResponse> On(Guid hardwareId);
    List<NotificationResponse> Off(Guid hardwareId);
}
