﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json;

namespace Domain;
public class UserHomePermission
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public Guid Id { get; set; } = new();
    public Guid UserId { get; set; }
    public User User { get; set; } = null!;

    public string PermissionsJson { get; set; } = string.Empty;

    [NotMapped]
    public List<HomePermission> Permissions
    {
        get => string.IsNullOrEmpty(PermissionsJson)
            ? []
            : JsonSerializer.Deserialize<List<HomePermission>>(PermissionsJson) ?? [];
        set => PermissionsJson = JsonSerializer.Serialize(value);
    }

    public Home Home { get; set; } = null!;
    public Guid HomeId { get; set; }
}
