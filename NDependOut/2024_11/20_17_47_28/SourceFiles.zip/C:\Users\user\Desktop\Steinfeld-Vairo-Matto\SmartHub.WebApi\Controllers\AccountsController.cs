﻿using BussinesLogic;
using Microsoft.AspNetCore.Mvc;
using WebApi.Filters;

namespace WebApi.Controllers;

[ServiceFilter(typeof(AuthenticationFilterAttribute))]
[ServiceFilter(typeof(AuthorizationFilterAttribute))]
[ApiController]
[Route("api/accounts")]
public class AccountsController : SmartHubBaseController
{
    private readonly IAccountService _accountService;

    public AccountsController(IAccountService accountService)
    {
        _accountService = accountService;
    }

    [HttpGet]
    public IActionResult GetAccounts(string? role = null, string? fullName = null, int pageNumber = 1, int pageSize = 10)
    {
        var accounts = _accountService.GetAll(role, fullName, pageNumber, pageSize);
        return Ok(accounts);
    }
}
