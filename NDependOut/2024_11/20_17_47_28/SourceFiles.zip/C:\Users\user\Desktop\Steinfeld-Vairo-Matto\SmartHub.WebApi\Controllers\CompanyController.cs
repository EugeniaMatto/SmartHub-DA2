﻿using BussinesLogic;
using Microsoft.AspNetCore.Mvc;
using Model.Request;
using WebApi.Filters;

namespace WebApi.Controllers;

[ServiceFilter(typeof(AuthenticationFilterAttribute))]
[ServiceFilter(typeof(AuthorizationFilterAttribute))]
[ApiController]
[Route("api/companies")]
public class CompaniesController : SmartHubBaseController
{
    private readonly ICompanyService _companyService;

    public CompaniesController(ICompanyService companyService)
    {
        _companyService = companyService;
    }

    [HttpPost]
    public IActionResult CreateCompany([FromBody] CompanyRequest request)
    {
        NotValidModel();

        var user = GetUserLogged();
        var id = _companyService.CreateCompany(request, user);

        return Ok(new { id });
    }

    [HttpGet]
    public IActionResult GetCompany(string? companyName = null, string? fullName = null, int pageNumber = 1, int pageSize = 10)
    {
        var companies = _companyService.GetAllCompanies(companyName, fullName, pageNumber, pageSize);
        return Ok(companies);
    }

    [HttpGet("user")]
    public IActionResult GetCompanyUser()
    {
        var user = GetUserLogged();
        return Ok(_companyService.GetCompany(user));
    }
}
