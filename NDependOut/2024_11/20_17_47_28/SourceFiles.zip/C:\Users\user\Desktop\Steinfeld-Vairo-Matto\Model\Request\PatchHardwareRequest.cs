﻿namespace Model;
public class PatchHardwareRequest
{
    public string Name { get; set; } = null!;
    public string HardwareId { get; set; } = null!;
}
