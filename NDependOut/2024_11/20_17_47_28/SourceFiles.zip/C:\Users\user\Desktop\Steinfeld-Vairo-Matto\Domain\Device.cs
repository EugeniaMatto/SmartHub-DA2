﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json;

namespace Domain;

public class Device
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Model { get; set; } = string.Empty;
    public DeviceType Type { get; set; }
    public string PhotosJson { get; set; } = string.Empty;

    [NotMapped]
    public List<string> Photos
    {
        get => string.IsNullOrEmpty(PhotosJson) ? [] : JsonSerializer.Deserialize<List<string>>(PhotosJson);
        set => PhotosJson = JsonSerializer.Serialize(value);
    }

    public string Description { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public Guid CompanyId { get; set; }
    public Company Company { get; set; } = null!;
    public override string ToString()
    {
        return $"Device Name: {Name}";
    }

    public Device()
    {
        CreatedAt = DateTime.Now;
        Id = Guid.NewGuid();
    }
}
