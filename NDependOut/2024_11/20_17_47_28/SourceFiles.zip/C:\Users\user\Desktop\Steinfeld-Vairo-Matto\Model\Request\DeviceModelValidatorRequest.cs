﻿namespace Model.Request;
public class DeviceModelValidatorRequest
{
    public required string Validator { get; set; }
}
