﻿using Model.Response;

namespace BussinesLogic;
public interface IAccountService
{
    PaginatedResult<AccountResponse> GetAll(string? role, string? fullName, int pageNumber, int pageSize);
}
