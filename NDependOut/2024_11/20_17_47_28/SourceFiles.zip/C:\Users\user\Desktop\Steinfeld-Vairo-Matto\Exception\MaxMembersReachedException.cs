﻿public class MaxMembersReachedException : Exception
{
    public MaxMembersReachedException(string message)
        : base(message)
    {
    }
}
