﻿using Model.Response;

namespace BussinesLogic;
public interface INotificationService
{
    List<NotificationResponse> GetNotifications(Guid? userId, bool? seen);
    List<NotificationResponse> AddNotification(Guid hardwareId, string descripcion);
}
