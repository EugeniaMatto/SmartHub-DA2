using Domain;
using Model.Request;
using Model.Response;

namespace BussinesLogic;

public interface ICompanyService
{
    Guid CreateCompany(CompanyRequest request, User user);
    PaginatedResult<CompanyModel> GetAllCompanies(string? companyName, string? fullName, int pageNumber, int pageSize);
    CompanyResponse GetCompany(User user);
}
