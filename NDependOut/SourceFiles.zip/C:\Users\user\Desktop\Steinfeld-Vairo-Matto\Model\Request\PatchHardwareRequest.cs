﻿namespace SmartHub.Model.Request;
public class PatchHardwareRequest
{
    public string Name { get; set; } = null!;
    public string HardwareId { get; set; } = null!;
}
