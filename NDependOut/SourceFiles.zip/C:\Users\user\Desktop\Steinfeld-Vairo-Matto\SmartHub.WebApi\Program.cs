using SmartHub.WebApi.Configuration;

ProgramConfiguration.Run(args);
